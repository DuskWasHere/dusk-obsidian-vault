---
Priority_Level: 1 Critical
Status: 1 To Do
Date_Created: 2024-11-12T23:54
Due_Date: 2024-11-14T23:54
connections:
tags:
  - "#project/projects"
type: project_note
cssclasses:
  - hide-properties_editing
  - hide-properties_reading
_previous_status: 1 To Do
---
# Components
**Select Connection:** `INPUT[inlineListSuggester(optionQuery(#area)):connections]` 
**Date Created:** `INPUT[dateTime(defaultValue(null)):Date_Created]`
**Due Date:** `INPUT[dateTime(defaultValue(null)):Due_Date]`
**Priority Level:** `INPUT[inlineSelect(option(1 Critical), option(2 High), option(3 Medium), option(4 Low)):Priority_Level]`
**Status:** `INPUT[inlineSelect(option(1 To Do), option(2 In Progress), option(3 Testing), option(4 Completed), option(5 Blocked)):Status]`
# **IMPORTANT**
**PLEASE CREATE YOUR FIRST PROJECT BEFORE DELETING THIS NOTE**
- The filters in the projects dashboard has been prepared for you
- It will reset if you do not have a note inside the **`PARA/PROJECTS`** folder
- Populate first by creating your first **`project family`** or **`project note`** before deleting this note
