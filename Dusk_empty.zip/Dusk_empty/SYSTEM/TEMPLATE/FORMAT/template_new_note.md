---
type: new_note
tags:
  - new_note
created: <% tp.file.creation_date() %>
---
<%tp.file.cursor()%>