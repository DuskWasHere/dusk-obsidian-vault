```dataviewjs
await dv.view("SYSTEM/TEMPLATE/CSS/Calendar", {pages: "", view: "week", firstDayOfWeek: "1", options: "style7"})
```
