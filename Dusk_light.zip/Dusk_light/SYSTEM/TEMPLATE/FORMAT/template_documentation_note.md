---
connections: []
reference: 
tags:
  - documentation_note
type: documentation_note
created: <% tp.file.creation_date() %>
---
**Select Connection:** `INPUT[inlineListSuggester(optionQuery(#project), optionQuery(#area)):connections]` 
<%tp.file.cursor()%>