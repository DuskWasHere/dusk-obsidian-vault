---
connections:
  - "[[PARA/AREAS/Space Tourism Initiatives/2. Space Tourism Initiatives.md|2. Space Tourism Initiatives]]"
tags:
  - workstation_note
type: workstation_note
created: 2024-11-12 05:00
---
**Select Connection:** `INPUT[inlineListSuggester(optionQuery(#project), optionQuery(#area), optionQuery(#workstation_note), optionQuery(#documentation_note)):connections]` 
Our current **UI/UX design** feels intuitive but needs **more user testing** to confirm effectiveness. We've received mixed feedback on navigation flow. We plan to conduct **targeted user testing sessions** to gather actionable insights.