---
company: Facebook
location: United States
title: CEO of Facebook
email: mark.zuckergerg@gmail.com
phone: "6505434800"
aliases:
  - Mark
tags:
  - contact/mark_zuckerberg
type: contact
---
# Personal Notes


# Scheduled Meetings
```dataview
TABLE scheduled_date as "Scheduled Date", start_time as "Start Time", summary as "Summary"
from #contact/mark_zuckerberg
where contains(type,"meeting")
sort meeting_status asc, scheduled_date asc
```
# Ongoing Tasks
```tasks
not done
tags include #contact/mark_zuckerberg
path does not include SYSTEM
sort by due date
```
# Completed Tasks
```tasks
done
tags include #contact/mark_zuckerberg
path does not include SYSTEM
sort by due date
```
