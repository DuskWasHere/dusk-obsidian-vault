---
Priority_Level: 1 Critical
Status: 2 In Progress
Date_Created: 2024-10-14T04:49
Due_Date: 2024-10-17T15:30
tags:
  - "#project/projects"
type: project_note
cssclasses:
  - hide-properties_editing
  - hide-properties_reading
_previous_status: 2 In Progress
---
# Components
**Date Created:** `INPUT[dateTime(defaultValue(null)):Date_Created]`
**Due Date:** `INPUT[dateTime(defaultValue(null)):Due_Date]`
**Priority Level:** `INPUT[inlineSelect(option(1 Critical), option(2 High), option(3 Medium), option(4 Low)):Priority_Level]`
**Status:** `INPUT[inlineSelect(option(1 To Do), option(2 In Progress), option(3 Testing), option(4 Completed), option(5 Blocked)):Status]`
# Description
Follow guides from **Vault Documentations** when refactoring your code. Create documentation from the actual implemented code. Create a documentation for the endpoints.
## Part 1
**Code Refactor:** Endpoints
**Documentations:**
- Endpoints
	- Invoice
	- Trial Balance
	- Bank Statement
**Test Final Output**
## Part 2
**Code Refactor:** CSV Update workflow (include trigger)
**Documentations:**
- The complete workflow
**Test Final Output**

## Part 3
**Code Refactor:** Trial Balance Classification Alternative
**Documentations:**
- The complete workflow
- Performance Analysis
**Test Final Output**