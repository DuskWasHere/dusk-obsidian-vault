---
connections: 
tags:
  - workstation_note
type: workstation_note
created: 2024-10-13 17:39
file_state: unchecked_task
---
**Select Connection:** `INPUT[inlineListSuggester(optionQuery(#project), optionQuery(#area), optionQuery(#workstation_note), optionQuery(#documentation_note)):connections]` 
# Learning Python Practices
Invest time to study good practices for writing code in Python
## Resources
[Solid Principles](https://www.youtube.com/watch?v=pTB30aXS77U&t=15s](https://www.youtube.com/watch?v=pTB30aXS77U&t=15s "https://www.youtube.com/watch?v=ptb30axs77u&t=15s")
[# The 3 Laws of Writing Readable Code](https://www.youtube.com/watch?v=-AzSRHiV9Cc)
[The 3 Laws of Writing Bug Free Code](https://www.youtube.com/watch?v=YMPlQCYp7xg)
[3 Coding Techniques To God-Tier Developer](https://www.youtube.com/watch?v=E7_gBwejLLw)
[My 10 “Clean” Code Principles (Start These Now)](https://www.youtube.com/watch?v=wSDyiEjhp8k)
[# 5 Signs of an Inexperienced Self-Taught Developer (and how to fix)](https://www.youtube.com/watch?v=B_HR2R3xsnQ)
## Solid Principles
1. Single Responsibility
    Make things (classes, functions, etc.) responsible for fulfilling one type of role.
        e.g. Refactor code responsibilities into separate classes.
2. Open/Closed
    Be able to add new functionality to existing code easily without modifying existing code.
        e.g. Use abstract classes. These can define what subclasses will require and strengthen Principle 1. by separating code duties.
3. Liskov Substitution
    When a class inherits from another class, the program shouldn't break and you shouldn't need to hack anything to use the subclass.
        e.g. Define constructor arguments to keep inheritance flexible.
4. Interface Segregation
     Make interfaces (parent abstract classes) more specific, rather than generic.
        e.g. Create more interfaces (classes) if needed and/or provide objects to constructors.
5. Dependency Inversion
    Make classes depend on abstract classes rather than non-abstract classes.
        e.g. Make classes inherit from abstract classes.
