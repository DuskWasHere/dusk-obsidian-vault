---
area: Nginx Implementation
tags: area/nginx_implementation/hsts_-_http_strict_transport_security_(includesubdomains)
type: area_note_sub
created: 2024-10-13 16:36
---
# [[1. Nginx Implementation]] 
# **HSTS - HTTP Strict Transport Security (includeSubDomains)**
### `default.conf`
Change this:
```
add_header Strict-Transport-Security "max-age=63072000" always;
```
to this:
```
add_header Strict-Transport-Security "max-age=63072000; includeSubDomains; preload" always;
```
## Reason:
Strict-Transport-Security
	[`includeSubDomains`](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Strict-Transport-Security#includesubdomains) <mark style="background: #BBFABBA6;">Optional</mark>  but it is suggested to have this implemented
	If this optional parameter is specified, this rule applies to all of the site's subdomains as well.
- This directive extends the HSTS policy to all subdomains of the current domain.
- <mark style="background: #BBFABBA6;">It ensures that all subdomains are also accessed over HTTPS</mark>, providing an additional layer of security.
## Considerations:
1. <mark style="background: #FF5582A6;">Be cautious with includeSubDomains if you have subdomains that can't support HTTPS</mark>.
2. The preload option is powerful but can be <mark style="background: #FF5582A6;">difficult to undo</mark>. <mark style="background: #ABF7F7A6;">Ensure all subdomains support HTTPS before using it.</mark>
3. To actually preload your domain, you need to submit it to hstspreload.org after adding this header.
<mark style="background: #FF5582A6;">The new header provides stronger security guarantees but requires careful consideration of your entire domain infrastructure. It's a positive change if your setup can support it fully.</mark>
## Additional Important Context:
- [HSTS - HTTP Strict Transport Security - Protect against SSL Stripping attack - Practical TLS](https://youtu.be/-MWqSD2_37E?si=UGbDeP9xriRFExJ2&t=367)
>[!warning] SSL Stripping
>An SSL stripping attack is a man-in-the-middle attack where an attacker intercepts and downgrades a user's HTTPS connection to HTTP by blocking or removing the site's HTTPS redirect. This leaves the user on an unencrypted HTTP connection, allowing the attacker to intercept or modify sensitive data. HSTS (HTTP Strict Transport Security) helps prevent this attack by ensuring the browser automatically enforces HTTPS and disallows insecure HTTP connections.
- `max-age` parameter sets the duration (in seconds) for which the browser should remember that the site must be accessed over HTTPS (2 years). However, this only applies to **the main domain** unless `includeSubDomains` is specified.
	- If no specified, subdomains (like `sub.example.com`, `api.example.com`, `mail.example.com`, etc.) could still be vulnerable to man-in-the-middle attacks over HTTP unless they also explicitly enforce HSTS separately.
## Question:
Can all our sub domains handle HTTPS?
- Yes
	- Implement
- No
	- Discuss with the team: BE, FE, etc...
# **Very Important**
### Best practices:
- Use includeSubDomains only if all subdomains support HTTPS.
- Consider adding preload directive for even stronger security, but be very careful as it's difficult to undo.
### Things to avoid:
- Don't set HSTS if you're not ready to fully commit to HTTPS.
- Avoid setting too long max-age initially, as it can be problematic if you need to revert to HTTP.
