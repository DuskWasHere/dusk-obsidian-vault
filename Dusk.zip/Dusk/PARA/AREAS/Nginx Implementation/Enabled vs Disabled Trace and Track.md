---
area: Nginx Implementation
tags: area/nginx_implementation/enabled_vs_disabled
type: area_note_sub
created: 2024-10-13 16:50
---
# [[1. Nginx Implementation]] 
# **Trace**
### Example Request with `TRACE` Enabled
#### Request:
```http
TRACE /api/some-endpoint HTTP/1.1
Host: yourdomain.com
User-Agent: curl/7.68.0
Content-Length: 0
```
#### Response (with `TRACE` enabled):
```http
HTTP/1.1 200 OK
Date: Mon, 30 Sep 2024 05:10:10 GMT
Server: nginx
Content-Type: message/http
Content-Length: 88

TRACE /api/some-endpoint HTTP/1.1
Host: yourdomain.com
User-Agent: curl/7.68.0
Content-Length: 0
```
### Example Request with `TRACE` Disabled
#### Request:
```http
TRACE /api/some-endpoint HTTP/1.1
Host: yourdomain.com
User-Agent: curl/7.68.0
Content-Length: 0
```
#### Response (with `TRACE` disabled):
```http
HTTP/1.1 405 Method Not Allowed
Date: Mon, 30 Sep 2024 05:12:15 GMT
Server: nginx
Content-Length: 0
Allow: GET, POST, OPTIONS
```
When `TRACE` is disabled, the server responds with a `405 Method Not Allowed` status, indicating that the method is not supported on this server.
# **Track**
### Example Request with `TRACK` Enabled
`TRACK` is an HTTP method used in some web servers like Microsoft IIS (Internet Information Services) and behaves similarly to `TRACE`. However, it is rarely seen in modern web servers like nginx or Apache.
#### Request:
```http
TRACK /api/some-endpoint HTTP/1.1
Host: yourdomain.com
User-Agent: curl/7.68.0
Content-Length: 0
```
#### Response (with `TRACK` enabled):
```http
HTTP/1.1 200 OK
Date: Mon, 30 Sep 2024 05:14:30 GMT
Server: nginx
Content-Type: message/http
Content-Length: 88

TRACK /api/some-endpoint HTTP/1.1
Host: yourdomain.com
User-Agent: curl/7.68.0
Content-Length: 0
```
The server responds similarly to `TRACE`, echoing the original request back to the client.
### Example Request with `TRACK` Disabled
#### Request:
```http
TRACK /api/some-endpoint HTTP/1.1
Host: yourdomain.com
User-Agent: curl/7.68.0
Content-Length: 0
```
#### Response (with `TRACK` disabled):
```http
HTTP/1.1 405 Method Not Allowed
Date: Mon, 30 Sep 2024 05:16:10 GMT
Server: nginx
Content-Length: 0
Allow: GET, POST, OPTIONS
```
Similarly, the server responds with a `405 Method Not Allowed`, rejecting the `TRACK` request.
