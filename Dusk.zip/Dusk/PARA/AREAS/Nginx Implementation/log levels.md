---
area: Nginx Implementation
tags: area/nginx_implementation/log_levels
type: area_note_sub
created: 2024-10-13 16:31
---
# [[1. Nginx Implementation]] 
# **Log Levels**
- debug
- info
- notice
- warn
- error
- crit
- alert
- emerg
