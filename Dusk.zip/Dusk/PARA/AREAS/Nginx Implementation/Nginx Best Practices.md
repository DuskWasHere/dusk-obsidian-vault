---
area: Nginx Implementation
tags: area/nginx_implementation/nginx_best_practices
type: area_note_sub
created: 2024-10-13 16:42
---
# [[1. Nginx Implementation]] 
# **Resources**
- [Nginx v1.25.1 http2 on; new recommendation](https://stackoverflow.com/questions/78195706/nginx-v1-25-1-http2-on-new-recommendation-creating-another-warn)
- [# Explained: 7 Settings to Secure Nginx Web Server | Securing Nginx](https://www.youtube.com/watch?v=HaY8QB5kkGw)
- [Missing HTTP Security Headers - Bug Bounty Tips](https://www.youtube.com/watch?v=064yDG7Rz80)
# **Nginx Configurations**
## 1. <mark style="background: #FF5582A6;">Disable Unused Nginx Modules</mark> <font color="#4f81bd">(Nginx is being used as a pre-built Docker image)</font>
Like most web server platforms, Nginx is installed with a host of modules—many of which are unnecessary, and therefore should be disabled to minimize the risk of potential attacks. This can be accomplished with the **configure** option during installation.
## 2. <mark style="background: #BBFABBA6;">Disable the Display of Nginx Version Number (Implemented)</mark>

![[Nginx Best Practices.png]]
![[Nginx Best Practices-1.png]]
By default, the **server_tokens** directive is set to display Nginx’s version number on all automatically generated error pages (e.g, 404 pages). This should be disabled by setting **server_tokens** off.

Add the line server_tokens off; inside the server block that handles HTTPS traffic (the one listening on port 443).
```
  ssl_certificate_key /nginx/ssl/privkey.pem;
  server_tokens off;  # Add this line to disable Nginx version display
  // ... existing code ...
```
**Implementing this will do the following:**
- Prevents automated attacks
	- Attackers often scan systems for version numbers to identify potential targets that are running outdated or vulnerable versions
	- Some automated bots and scripts are designed to search for specific versions of software
**Downside:**
- Slight increase in troubleshooting difficulty
## 2.1 Rate Limiting <mark style="background: #BBFABBA6;">(Implemented)</mark>
**Look here for detailed notes:** [[Rate Limiting]]
## _3._ <mark style="background: #FF5582A6;">Set Client Buffer Size Limitations</mark> <font color="#4f81bd">(help prevent potential buffer overflow attacks but setting these values, as overly restrictive settings might interfere with legitimate requests)</font>
**This helps to prevent buffer overflow attacks from occurring** by setting buffer size limitations for clients. Modifications to Nginx configuration file directives like **client_body_buffer_size**, **client_header_buffer_size**, **client_max_body_size**, and **large_client_header_buffers** can help to this end.

- **clientbodybuffer_size:** Sets the buffer size for the client request body. If the body is larger than this buffer, the entire (or part) of the body is written to a temporary file.
- **clientheaderbuffer_size**: Specifies the buffer size for reading client request header. For most requests, a buffer of 1K bytes is enough.
- **largeclientheader_buffers:** Specifies the maximum number and size of buffers for large client headers.
## 4. <mark style="background: #FF5582A6;">Disable Unnecessary HTTP Methods</mark> <font color="#4f81bd">(we use nginx as a reverse proxy and gateway for our API. This should not be implemented here)</font>
Typically, GET, HEAD, and POST methods are required for web operations, while others such as DELETE and TRACE are unnecessary. The necessary conditions should be added to the ‘server’ section in the Nginx configuration file to block other methods from being [exploited](https://www.upguard.com/blog/exploit)
## 5. <mark style="background: #BBFABBA6;">Disable TRACE and TRACK. (Protect API)</mark>
<font color="#4f81bd">The TRACE and TRACK HTTP methods are used for debugging connections, but can be exploited to intercept visitors’ sensitive data.</font> Disabling these two methods can effectively prevent this from occurring.

**Look here for comparison:** [[Enabled vs Disabled Trace and Track]]
> [!multi-column]
>> [!tip] Functionality
>> - TRACE: This method echoes back the received request, allowing the client to see what changes or additions have been made by intermediate servers.
>> - TRACK: Similar to TRACE, but less commonly used. It's not part of the HTTP standard.
>
>> [!tip] Security
>> - When enabled, these methods can potentially be exploited in cross-site tracing (XST) attacks, where an attacker might gain access to sensitive information like cookies or authentication headers.

**For a production environment, it's recommended to disable TRACE and TRACK methods.** The security benefits significantly outweigh the minimal loss in functionality. Most production systems operate perfectly well without these methods enabled.

To disable TRACE and TRACK methods, you can add the following to your server block:
```
if ($request_method ~* "^TRACE|TRACK$") {
  return 405;
}
```
This effectively disabling TRACE, TRACK, and any other methods not explicitly allowed.
- ! If you need to debug HTTP connections, consider using more secure methods like server-side logging or dedicated debugging tools.
## 6. <mark style="background: #FF5582A6;">Install the ModSecurity Module.</mark> <font color="#4f81bd">(Modsecurity is at its EOL, implement with alternatives like)</font>
As its name implies, the ModSecurity module enables better security within Nginx—essentially serving as a [web application firewall](http://www.upguard.com/blog/web-application-firewall). It’s therefore highly recommended to install the mod_security module in order to bolster Nginx’s native security.
## 7. Security Headers Configurations <mark style="background: #BBFABBA6;">(Implemented)</mark>
- / **Security Headers to include:**
	- [Strict-Transport-Security (HSTS)](obsidian://open?vault=Dawn&file=01%20-%20Projects%2FSecurity%20Implementation%2FHSTS%20-%20HTTP%20Strict%20Transport%20Security%20(includeSubDomains))
- / **and the following:**
````tabs

tab: X-Content-Type-Options
### What it is:
This header prevents MIME type sniffing, which is a security exploit where the browser tries to guess and execute the content type of a resource.
### How to implement:
```
add_header X-Content-Type-Options "nosniff" always;
```
### Considerations:
- This is a simple header with only one valid value: "nosniff".
- It's widely supported across modern browsers.
### Best practices:
- Always include this header as it's simple to implement and provides good security benefits.
### Things to avoid:
- Don't omit this header, as MIME type sniffing can lead to security vulnerabilities.

tab: X-Frame-Options
### What it is:
This header helps prevent clickjacking attacks by disabling or restricting iframe embedding of your site.
### How to implement:
```
add_header X-Frame-Options "SAMEORIGIN" always;
```
### Considerations:
- "SAMEORIGIN" allows framing by pages on the same origin as the page being framed.
- Other possible values are "DENY" (no framing allowed) and "ALLOW-FROM uri" (specific origin allowed).
### Best practices:
- Use "SAMEORIGIN" if you need to use iframes within your own site.
- Use "DENY" for maximum security if you don't need framing at all.
### Things to avoid:
- Don't use "ALLOW-FROM" as it's not supported by all browsers.
- Avoid omitting this header, as it leaves your site vulnerable to clickjacking attacks.

tab: Referrer-Policy:
### What it is:
This header controls how much referrer information should be included with requests.
### How to implement:
```
add_header Referrer-Policy "strict-origin-when-cross-origin" always;
```
### Considerations:
- "strict-origin-when-cross-origin" sends the origin, path, and querystring when performing a same-origin request, only the origin when the protocol security level stays the same (HTTPS→HTTPS), and no header when the protocol security level changes (HTTPS→HTTP).
````
- ! **Not Included:**
````tabs
tab: Content-Security-Policy (CSP)
### Purpose: 
- Mitigates XSS attacks by specifying which resources can be loaded.
### Reason for exclusion: 
- Complex to implement correctly; requires careful tuning to avoid breaking functionality.

tab: Feature-Policy / Permissions-Policy
### Purpose: 
- Controls browser features and APIs that can be used by the site.
### Reason for exclusion: 
- May not be necessary for all applications; can potentially limit desired functionality.

````
