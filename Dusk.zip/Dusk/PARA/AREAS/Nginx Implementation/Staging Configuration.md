---
area: Nginx Implementation
summary: Monitored and approved Stating configurations
tags:
  - area/nginx_implementation/staging_configuration
type: area_note
created: 2024-10-13 15:32
---
# [[1. Nginx Implementation]] 
# **Overview**
This document provides an overview of a typical NGINX configuration for a web application server. It explains the purpose and function of each configuration component to ensure secure, efficient, and well-understood server management.
#### Table of Contents
1. Global Configurations
2. Upstream Servers
3. Rate Limiting
4. Default Server Block
5. HTTP Server Block (Port 80)
   - Security Configurations
   - Redirect to HTTPS
6. HTTPS Server Block (Port 443)
   - SSL Configuration
   - Security Headers
   - Logging
   - Security Configurations
   - Proxy Settings
   - Allowed Locations
---
## 1. Global Configurations
- **Hide NGINX Version**
  ```nginx
  server_tokens off;
  ```
  - Prevents the NGINX version number from being displayed, reducing potential attack vectors.

- **Set Character Encoding**
  ```nginx
  charset utf-8;
  ```
  - Sets default character encoding to UTF-8 for all responses.

## 2. Upstream Servers
- **Example Upstream**
  ```nginx
  upstream backend {
      server backend-service:80;
  }
  ```
  - Defines an upstream group named `backend` pointing to a backend service on port 80.

## 3. Rate Limiting
- **Rate Limiting Configuration**
  ```nginx
  limit_req_zone $binary_remote_addr zone=limit_zone:10m rate=10r/s;
  ```
  - Creates a rate-limiting zone named `limit_zone` with a 10MB size.
  - Limits each IP address to 10 requests per second.

## 4. Default Server Block
- **Reject Invalid Hosts**
  ```nginx
  server {
      listen 80 default_server;
      listen [::]:80 default_server;
      server_name _;
      return 444;
  }
  ```
  - Captures unspecified host requests and closes the connection without a response (HTTP 444).

## 5. HTTP Server Block (Port 80)
Handles incoming HTTP requests and redirects them to HTTPS.
```nginx
server {
    listen 80;
    listen [::]:80;
    server_name example.com localhost 127.0.0.1 [::1];
    ...
}
```

### Security Configurations
- **Block TRACE and TRACK Methods**
  ```nginx
  if ($request_method ~* "^TRACE|TRACK$") {
      return 405;
  }
  ```
  - Denies TRACE and TRACK methods to prevent potential security risks like cross-site tracing.

- **Deny Common Bot User Agents**
  ```nginx
  if ($http_user_agent ~* "(curl|wget|python|bot|crawler|spider|^$)") {
      return 403;
  }
  ```
  - Blocks known bots and automated scripts to reduce malicious activity.

- **Deny Access to Sensitive Files**
  ```nginx
  location ~* (\.env|\.ini|\.log|\.conf|\.sql|\.git|\.svn)$ {
      return 403;
  }
  ```
  - Denies access to sensitive file types.

### Redirect to HTTPS
- **Enforce HTTPS**
  ```nginx
  location / {
      return 301 https://$host$request_uri;
  }
  ```
  - Redirects all HTTP traffic to HTTPS.

## 6. HTTPS Server Block (Port 443)
Handles all HTTPS requests with strict security measures.
```nginx
server {
    server_name example.com localhost 127.0.0.1 [::1];
    listen [::]:443 ssl;
    listen 443 ssl;
    http2 on;
    ...
}
```

### SSL Configuration
- **SSL Certificates**
  ```nginx
  ssl_certificate /path/to/fullchain.pem;
  ssl_certificate_key /path/to/privkey.pem;
  ssl_trusted_certificate /path/to/fullchain.pem;
  ```
  - Specifies the paths to the SSL certificate and key files.

- **Protocols and Ciphers**
  ```nginx
  ssl_protocols TLSv1.2 TLSv1.3;
  ssl_ciphers ECDHE-ECDSA-AES128-GCM-SHA256:...;
  ssl_prefer_server_ciphers on;
  ```
  - Enforces secure TLS protocols and strong cipher suites.

### Security Headers
- **Strict Transport Security (HSTS)**
  ```nginx
  add_header Strict-Transport-Security "max-age=63072000; includeSubDomains; preload" always;
  ```
  - Instructs browsers to use HTTPS for all future requests.

- **MIME Sniffing Prevention**
  ```nginx
  add_header X-Content-Type-Options "nosniff" always;
  ```

- **Clickjacking Protection**
  ```nginx
  add_header X-Frame-Options "SAMEORIGIN" always;
  ```

- **Referrer Policy**
  ```nginx
  add_header Referrer-Policy "strict-origin-when-cross-origin" always;
  ```

### Logging
- **Access and Error Logs**
  ```nginx
  access_log /var/log/nginx/access.log;
  error_log /var/log/nginx/error.log error;
  ```
  - Configures access and error logs.

### Proxy Settings
- **Proxy Headers**
  ```nginx
  proxy_set_header Host $host;
  proxy_set_header X-Real-IP $remote_addr;
  proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
  ```

### Allowed Locations
- **API Endpoints Example**
  ```nginx
  location /api/v1/ {
      limit_req zone=limit_zone burst=5 nodelay;
      proxy_pass http://backend;
  }
  ```
  - Proxies API requests with rate limiting to the backend service.
