---
area: Nginx Implementation
tags: area/nginx_implementation/log_rotation
type: area_note_sub
created: 2024-10-13 16:33
---
# [[1. Nginx Implementation]] 
# **Log Rotation**
Log rotation saves space through several mechanisms:
- It compresses old log files, significantly reducing their size.
- It allows you to set a limit on how many old log files to keep (e.g., 14 days worth).
- Once the limit is reached, the oldest logs are deleted.
