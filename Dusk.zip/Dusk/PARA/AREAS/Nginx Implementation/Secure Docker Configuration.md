---
area: Nginx Implementation
tags: area/nginx_implementation/secure_docker_configuration
type: area_note_sub
created: 2024-10-13 16:39
---
# [[1. Nginx Implementation]] 
# **Secure Docker Deployment**
**Importance:** Medium
**Description:**
- **Harden Docker Containers:** Ensure that your Docker containers are securely configured.
## Implementation Steps:
### Use Official Base Images:
  - **Specify Image Versions:**
    - Replace `latest` tags with specific version numbers to avoid unintended updates.
### Run Containers as Non-Root:
  - **Modify Dockerfiles:**
    - Add a non-root user and switch to it.
      ```dockerfile
      RUN adduser -D myuser
      USER myuser
      ```
## Limit Container Capabilities:
  ###  **Update Docker Compose:**
- Add security options to services.
  ```yaml
  services:
	api:
	  ...
	  security_opt:
		- no-new-privileges:true
  ```
**Reasoning:**
- **Prevent Container Breakouts:** Running as non-root reduces the risk of privilege escalation.
- **Stable Deployments:** Using specific image versions ensures consistency across deployments.
