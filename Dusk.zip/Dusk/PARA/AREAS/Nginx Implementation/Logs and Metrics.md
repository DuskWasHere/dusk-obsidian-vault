---
area: Nginx Implementation
tags: area/nginx_implementation/logs_and_metrics
type: area_note_sub
created: 2024-10-13 16:30
---
# [[1. Nginx Implementation]] 
# **Logs and Metrics**
- [[log levels]]
- [[use cases for access and error logs]]
- Nginx current config only captures error logs (excluding debug, info, notice, and warn)
	- you still see the following: crit, alert, emerg
- I've enabled access logs with [[combined log format]]
	- solution: [How to Monitor Nginx with Prometheus and Grafana](https://www.youtube.com/watch?v=H45YV-l6GOY)
- Implement [[log rotation]] if you do not have a centralized logging system <mark style="background: #FF5582A6;">(NO NEED IF IMPLEMENTING ELK)</mark>
- continue implementation with and ELK, EFK stack or Prometheus and Grafana
![[Logs and Metrics.png]]
Centralized logging system like ELK (Elasticsearch, Logstash, Kibana), it's generally recommended to send logs directly to the centralized system
- Consistent with container philosophy: Treats containers as stateless, with all persistent data (including logs) managed externally.