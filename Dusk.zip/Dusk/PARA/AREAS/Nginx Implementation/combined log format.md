---
area: Nginx Implementation
tags: area/nginx_implementation/combined_log_format
type: area_note_sub
created: 2024-10-13 16:31
---
# [[1. Nginx Implementation]] 
# **Combined log format components**
- Client IP address
- Request date/time
- HTTP method, URI, and protocol
- Response status code
- Bytes sent
- Referer header
- User-Agent header
<mark style="background: #BBFABBA6;">This format is generally safe for production use</mark>
## Question:
Do we need to comply with specific privacy regulations? We might want to exclude or mask certain fields.
