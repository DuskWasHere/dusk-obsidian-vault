---
area: Nginx Implementation
summary: Compilation of research notes
tags:
  - area/nginx_implementation/user_manual
type: area_note
created: 2024-10-13 16:20
---
# [[1. Nginx Implementation]] 
# **To Implement**
### These are the components for security implementations:
1. [[Django Side]]
2. [[Logs and Metrics]]
3. [[HSTS - HTTP Strict Transport Security (includeSubDomains)]]
4. [[Rate Limiting]]
5. [[Secure Docker Configuration]]
### Other implementations (Nginx side):
1. [[Nginx Best Practices]]

### AWS side components:
1. AWS WAF (Web Application Firewall)
2. Network Security with AWS Security Groups
