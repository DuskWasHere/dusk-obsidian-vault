---
connections: 
tags:
  - permanent_note
type: permanent_note
created: <% tp.file.creation_date() %>
---
**Select Connection:** `INPUT[inlineListSuggester(optionQuery(#permanent_note), optionQuery(#literature_note), optionQuery(#fleeting_note)):connections]` 
<%tp.file.cursor()%>