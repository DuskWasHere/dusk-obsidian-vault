---
connections: []
reference: 
tags:
  - documentation
type: documentation
created: <% tp.file.creation_date() %>
---
**Select Connection:** `INPUT[inlineListSuggester(optionQuery(#project), optionQuery(#area)):connections]` 
<%tp.file.cursor()%>