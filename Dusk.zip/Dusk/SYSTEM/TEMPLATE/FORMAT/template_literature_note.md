---
connections: 
reference: 
tags:
  - literature_note
type: literature_note
created: <% tp.file.creation_date() %>
---
**Select Connection:** `INPUT[inlineListSuggester(optionQuery(#permanent_note), optionQuery(#literature_note), optionQuery(#fleeting_note)):connections]` 
<%tp.file.cursor()%>