```dataviewjs
dv.view("SYSTEM/TEMPLATE/CSS/Timeline", {
    pages: "", 
    inbox: "Inbox.md", 
    dailyNoteFolder: "DAILY/DAILY", 
    dailyNoteFormat: "YYYY-MM-DD",
    section: "# New Tasks",
    forward: true,
    options: "noYear todayFocus todoFilter noFile"
})
```
