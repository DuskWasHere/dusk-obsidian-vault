---
cssclasses:
  - no-inline
  - hide-properties_editing
  - hide-properties_reading
---
# Follow the instructions in the **Getting Started** Folder
**Directory: SYSTEM > GETTING STARTED**
# Follow the order:
1. [[Vault Onboarding Part 1]]
2. [[Vault Onboarding Part 2]]
3. [[Vault Onboarding Part 3]]
4. [[Vault Walkthrough]]
# Reference files:
1. [[Concept Inspiration and Reference]]
# Notes:
- / This vault creates a strong division between **PARA** and the **ZETA** (Zettelkasten) method of note taking. 
- / You can easily monitor **projects** with the **Project component**
- / The **Area component** allows you to **create MOC's** for topics you wish to explore
	- ? I like to use The **ZETA** component for inputs/concepts not related to **PARA** (since in my case PARA focuses on the development of a skill or things that are work related)
- ! In terms of styling and CSS, I did not heavily modify it so you can **personalize it to how you want the vault to look**
#### **I highly advise you to go over the documentations so you get to utilize the full potential of the vault**

# **Sample Look**
- / Some of the dataview tables in the **Homepage** are **listed/sorted based on the modified date** and the displayed notes are limited to **15** notes
	- & This will help you with scaling your vault so you can navigate to the most recent files
````tabs
tab: HUB
**Homepage**
![[Vault Onboarding Part Final.png]]
**Map of Content**
![[Getting Started Map of Content.png]]
**Mail Box**
![[Getting Started Mail Box.png]]

tab: Area
**Area Family**
![[Instructions (delete this when done).png|750]]
**Area Note**
![[Instructions (delete this when done)-3.png]]
tab: Project
**Project Dashboard**
![[Instructions (delete this when done)-2.png]]
**Project Note**
![[Instructions (delete this when done)-10.png]]
tab: Daily
**Daily Note**
![[Instructions (delete this when done)-5.png]]
**Weekly Note**
![[Instructions (delete this when done)-14.png]]
**Monthly Note**
![[Instructions (delete this when done)-15.png]]
- ? To quickly create a **daily/weekly/monthly** note, **double click on the calendar**
![[Instructions (delete this when done)-6.png]]
or here
![[Instructions (delete this when done)-7.png]]
tab: Meeting
**General Meeting**
![[Instructions (delete this when done)-12.png]]
- ? There are also **two other types of meeting notes**
	- Standup Meeting
	- Team Meeting
tab: Contacts
**Contacts**
![[Instructions (delete this when done)-13.png]]
- ? You can add a task or a meeting for a contact by using the `#contact/{name}`, please refer to [[Vault Walkthrough]] for more information
````


